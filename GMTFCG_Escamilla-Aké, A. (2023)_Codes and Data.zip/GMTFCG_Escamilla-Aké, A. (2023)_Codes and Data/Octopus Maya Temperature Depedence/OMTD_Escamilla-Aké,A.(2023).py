# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 08:41:41 2023

@author: Ángel Escamilla-Aké
"""
#BEGIN OF CODE

#**LIBRARY AND ROUTINE
from scipy.optimize import curve_fit
import numpy as np
import matplotlib.pyplot as plt
import math
import sympy as sym


#**PARAMETERS. We define the parameters of model.
#W0:= initial weight
#a1:= parameter alpha_1
#a2:= parameter alpha_2
#Tab:= parameter T_{alpha,beta}
#tau.= parameter tau
#b1.= parameter beta_1
#b2.= parameter beta_2

#**RELATIVE GROWTH RATE TEMPERATURE-DEPENDENT.
def RGRTD(t,a1,a2,Tab,tau,b1,b2):
  return (a1/(1+(a2/((25+Tab)**2))*(25-Tab)**2))-(b1/(1+(b2/((25+Tab)**2))*(25-Tab)**2))/(1+np.exp((((b1/(1+(b2/((25+Tab)**2))*(25-Tab)**2)))*((tau/((25)))-t))))
def Alpha(T,a1,a2,Tab):
    return a1/(1+(a2/(T+Tab)**2)*(T-Tab)**2)
def Beta(T,b1,b2,Tab):
    return b1/(1+(b2/(T+Tab)**2)*(T-Tab)**2)

#**PARAMETER VECTOR. Give a starting value: P0=[a1,a2,Tab,tau,b1,b2]
P0=[0.057407966024705125,10.545808509092131,26.398868657966695,4348.485566739955,0.05084996900978882,6.248861698055483]#Scope=21.07 Min 17.88 Max 38.96 Tab 26.39

#**DATA. We load the data.
datos = np.loadtxt('ROmayaVanHeukelem1976_25°C.prn')

#**FITTING. We make the fitting
x = datos[:, 0]
y = datos[:, 1]
popt, pcov = curve_fit(RGRTD,x,y,p0=P0)
P0=popt
#**CALCULATION AND DISPLAY OF VALUES
print('Determination coefficient')
ss_res = np.sum( (y - RGRTD(x, *popt))**2  )
ss_tot = np.sum( (y- np.mean(y) )**2  )
R2     = 1 - (ss_res / ss_tot)
print('R2 = {:10.8f}'.format(R2) )
P=np.vectorize(P0)
P=P0
Pa=[P[0],P[1],P[2]]
Pb=[P[4],P[5],P[2]]
print('alpha1')
alpha1=P[0]
print(alpha1)
print('alpha2')
alpha2=P[1]
print(alpha2)
print('Tab')
Tab=P[2]
print(Tab)
print('tau')
tau=P[3]
print(tau)
print('beta1')
beta1=P[4]
print(beta1)
print('beta2')
beta2=P[5]
print(beta2)
print('alpha')
alpha=(alpha1/(1+(alpha2/((25+Tab)**2))*(25-Tab)**2))
print(alpha)
print('beta')
beta=(beta1/(1+(beta2/((25+Tab)**2))*(25-Tab)**2))
print(beta)
print('kappa')
kappa=tau/25
print(kappa)
print('Delta')
Delta=beta**2-4*alpha*(alpha-beta)
print(Delta)
print('mu1')
mu1=kappa+(1/beta)*math.log(abs((2*alpha**2)/((alpha+beta)**2-3*alpha**2+beta*(Delta)**(1/2))))
print(mu1)
print('mu2')
mu2=kappa+(1/beta)*math.log(abs((2*alpha**2)/((alpha+beta)**2-3*alpha**2-beta*(Delta)**(1/2))))
print(mu2)
print('alpha relative average')
Aave=alpha-(1/mu2)*math.log((np.exp(beta*mu2)+np.exp(beta*kappa))/(1+np.exp(beta*kappa)))
print(Aave)
print('Tmin')
T=sym.Symbol('T')
resp=sym.solve([Alpha(T,P[0],P[1],P[2])-Beta(T,P[4],P[5],P[2])], dict=True)
r1=resp[0]
Tmin=r1.get(T)
print(Tmin)
print('Tmax')
r2=resp[1]
Tmax=r2.get(T)
print(Tmax)
print('Thermal window scope')
TWScope=Tmax-Tmin
print(TWScope)
TS=str(TWScope)
fig=plt.figure(figsize=(20,5))
fig.tight_layout()
ax1=fig.add_subplot(1,2,1)
ax2=fig.add_subplot(1,2,2)
x_fit = np.linspace(x[0], x[-1], 1000, endpoint=True)
ax1.plot(x,y,'o',label = 'Model data')
ax1.plot(x_fit,RGRTD(x_fit,*popt),'g--',label='Parameters fit')
ax1.legend(loc='best')
ax1.set_xlabel('Time (days)')
ax1.set_ylabel('Rate (1/day)')
ax1.set_title('Relative rate')
ax1.grid()
T_fit = np.linspace(18,40, 1000, endpoint=True)
ax2.plot(T_fit,Alpha(T_fit,*Pa),'y-',label='$\\alpha(T)$')
ax2.plot(T_fit,Beta(T_fit,*Pb),'b-',label='$\\beta(T)$')
ax2.legend(loc='best')
ax2.axhline(y=0.037,color='green',linestyle='dashed')
ax2.axvline(x=Tmin,color='blue',linestyle='dashed')
ax2.axvline(x=Tmax,color='red',linestyle='dashed')
ax2.annotate('Thermal window scope = '+ TS, (23, 0.038))
ax2.set_xlabel('Temperature (°C)')
ax2.set_ylabel('Rate(1/day)')
ax2.set_title('Thermal window scope of O. maya')
ax2.grid()

#END OF CODE

