# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 08:41:41 2023

@author: Ángel Escamilla-Aké
"""
#BEGIN OF CODE

#**LIBRARY AND ROUTINE
import math
import numpy as np 

#**PARAMETER VECTOR. Give a starting value: P0=[a1,a2,Tab,tau,b1,b2]
P0=[0.057407966024705125,10.545808509092131,26.398868657966695,4348.485566739955,0.05084996900978882,6.248861698055483]

#**CALCULATION AND DISPLAY OF VALUES
P=np.vectorize(P0)
P=P0
a1=P[0];a2=P[1];Tab=P[2];t1=P[3];b1=P[4];b2=P[5]
T=18 #Give a temperature value
print('Temperature')
print(T)
print('alpha')
alpha=(a1/(1+(a2/(T+Tab)**2)*(T-Tab)**2))
print(alpha)
print('beta')
beta=(b1/(1+(b2/(T+Tab)**2)*(T-Tab)**2))
print(beta)
print('kappa')
kappa=t1/(T)
print(kappa)
print('Delta')
Delta=beta**2-4*alpha*(alpha-beta)
print(Delta)
print('mu1')
mu1=kappa+(1/beta)*math.log(abs((2*alpha**2)/((alpha+beta)**2-3*alpha**2+beta*(Delta)**(1/2))))
print(mu1)
print('mu2')
mu2=kappa+(1/beta)*math.log(abs((2*alpha**2)/((alpha+beta)**2-3*alpha**2-beta*(Delta)**(1/2))))
print(mu2)
print('alpha average')
Aave=alpha-(1/mu2)*math.log((np.exp(beta*mu2)+np.exp(beta*kappa))/(1+np.exp(beta*kappa)))
print(Aave)

#END OF CODE