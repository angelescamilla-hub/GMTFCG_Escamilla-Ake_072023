# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 08:41:41 2023

@author: Ángel Escamilla-Aké
"""
#BEGIN OF CODE

#**LIBRARY AND ROUTINE
import math
import numpy as np  
import matplotlib.pyplot as plt  

#**PARAMETERS. We define the parameters of model.
#W0:= initial weight
#a1:= parameter alpha_1
#a2:= parameter alpha_2
#Tab:= parameter T_{alpha,beta}
#tau:= parameter tau
#b1:= parameter beta_1
#b2:= parameter beta_2

#**INITIAL WEIGHT. We fix the value of incitial weight
W0=0.1

#**BIOMASS GROWTH FUNCTION TEMPERATURE-DEPENDENT OF OCTOPUS MAYA
def BGFTDOM(T,a1,a2,Top,t1,b1,b2):
    return W0*(np.exp(((((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))-((b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))))*((t1/(T))+(1/(b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))*math.log(abs((2*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))**2)/((((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))+((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))))**2-3*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))**2-((b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))*(((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))**2-4*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2))-((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))))))**(1/2)))))))*((1+np.exp(((b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))*(t1/(T))))/(1+np.exp(((b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))*((t1/(T))-((t1/(T))+(1/(b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))*math.log(abs((2*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))**2)/((((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))+((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))))**2-3*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))**2-((b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))*(((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))**2-4*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2))-((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))))))**(1/2)))))))))
BGF= np.vectorize(BGFTDOM)

#**AVERAGE GROWTH RATE OF OCTOPUS MAYA
def AGROM(T,a1,a2,Top,t1,b1,b2):
    return (a1/(1+(a2/(T+Top)**2)*(T-Top)**2))-(1/((t1/(T)+(1/(b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))*math.log(abs((2*(a1/(1+(a2/(T+Top)**2)*(T-Top)**2))**2)/(((a1/(1+(a2/(T+Top)**2)*(T-Top)**2))+(b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))**2-3*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))**2-((b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))*((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))**2-4*(a1/(1+(a2/(T+Top)**2)*(T-Top)**2))*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2))-(b1/(1+(b2/(T+Top)**2)*(T-Top)**2))))**(1/2)))))))*math.log((np.exp((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))*((t1/(T)+(1/(b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))*math.log(abs((2*(a1/(1+(a2/(T+Top)**2)*(T-Top)**2))**2)/(((a1/(1+(a2/(T+Top)**2)*(T-Top)**2))+(b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))**2-3*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2)))**2-((b1/(1+(b2/(T+Top)**2)*(T-Top)**2)))*((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))**2-4*(a1/(1+(a2/(T+Top)**2)*(T-Top)**2))*((a1/(1+(a2/(T+Top)**2)*(T-Top)**2))-(b1/(1+(b2/(T+Top)**2)*(T-Top)**2))))**(1/2)))))))+np.exp((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))*(t1/(T))))/(1+np.exp((b1/(1+(b2/(T+Top)**2)*(T-Top)**2))*(t1/(T)))))
AGR= np.vectorize(AGROM)

#**PARAMETER VECTOR. Give a starting value: P0=[a1,a2,Tab,tau,b1,b2]
P0=[0.057407966024705125,10.545808509092131,26.398868657966695,4348.485566739955,0.05084996900978882,6.248861698055483]
Pa=[0.057407966024705125,10.545808509092131,26.398868657966695]
Pb=[0.05084996900978882,6.248861698055483,26.398868657966695]

#**CALCULATION AND DISPLAY OF VALUES
fig=plt.figure(figsize=(20,5))
fig.tight_layout()
ax1=fig.add_subplot(1,2,1)
ax2=fig.add_subplot(1,2,2)
T_fit = np.linspace(10,38, 1000, endpoint=True)#We choose a temperature range with T>0 to avoid divergence.
#T_fit = np.linspace(21.728780,21.728790, 1000, endpoint=True)#higher biomass found by inspection at T_{opt,biomass}=21.728785 °C
ax1.plot(T_fit,BGF(T_fit,*P0),'g-',label='W($\\mu_{max}$,T)')
ax1.annotate("$T_{opt,biomass}=21.7 °C$", (10, 3000))# T_{opt,biomass}=23.3679577 °C
ax1.legend(loc='best')
ax1.set_xlabel('Temperature (°C)')
ax1.set_ylabel('Weight (g)')
ax1.axvline(x=21.728785,color='red',linestyle='dashed')
ax1.set_title('Maximum weight of O. maya with $W_0$=0.1 g')
ax1.grid()

x_fit = np.linspace(17.8870990204436,38.9610589053565, 1000, endpoint=True)# Interval CT_{min} to CT_{max} according our model
#x_fit = np.linspace(25.734654,25.734656, 1000, endpoint=True)# higher rate found by inspection at T_{opt,rate}=25.734655 °C
ax2.plot(x_fit,AGR(x_fit,*P0),'g-',label='$\\alpha_{rel,ave}(\mu_{max},T)$')
ax2.legend(loc='best')
ax2.axvline(x=25.734655,color='red',linestyle='dashed')
##ax2.axvline(x=17.8870990204436,color='red',linestyle='dashed')#Vertical asymtote at T_{min}
##ax2.axvline(x=38.9610589053565,color='red',linestyle='dashed')#Vertical asymtote at T_{max}
ax2.set_ylabel('Rate(1/day)')
ax2.set_title('Average growth rate O. maya')
ax2.annotate('$T_{opt,rate} =  $ 25.7°C', (21, 0.020))#T_{opt,rate}=25.734655 °C
ax2.grid()

#END OF CODE
