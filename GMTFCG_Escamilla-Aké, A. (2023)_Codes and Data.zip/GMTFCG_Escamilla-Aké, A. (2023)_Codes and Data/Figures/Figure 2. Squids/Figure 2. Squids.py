# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 08:41:41 2023

@author: Ángel Escamilla
"""
#BEGIN OF CODE

#**LIBRARY AND ROUTINE
import numpy as np  
import matplotlib.pyplot as plt  

#**CONFIGURATION
fig=plt.figure(figsize=(20,15))
fig.tight_layout()

ax1=fig.add_subplot(4,3,1)
ax2=fig.add_subplot(4,3,2)
ax3=fig.add_subplot(4,3,3)
ax4=fig.add_subplot(4,3,4)
ax5=fig.add_subplot(4,3,5)
ax6=fig.add_subplot(4,3,6)

ax7=fig.add_subplot(4,3,7)
ax8=fig.add_subplot(4,3,8)
ax9=fig.add_subplot(4,3,9)
ax10=fig.add_subplot(4,3,10)
ax11=fig.add_subplot(4,3,11)
ax12=fig.add_subplot(4,3,12)

#**BIOMASS GROWTH FUNCTION. We define the biomass growth function, Eq. (7) in our paper
def Weight(t,W0,a,b,mu):
    return W0*(np.exp((a-b)*t))*((1+np.exp(b*mu))/((1+np.exp(b*(mu-t)))))

#**RELATIVE GROWTH RATE. We define the biomass growth function, Eq. (4) in our paper
def Rate(t,a,b,mu):
    return a-(b/(1+np.exp(b*((mu)-t))))

#**TIME DERIVATIVE OF BIOMASS GROWTH FUNCTION. We calculate the time derivative biomass growth function
def Derivative(t,W0,a,b,mu):
   return W0*(1+np.exp(b*mu))*(((b*np.exp((a-b)*t+b*(mu-t)))/(1+np.exp(b*(mu-t)))**2)+(((a-b)*np.exp((a-b)*t))/(1+np.exp(b*(mu-t)))))

########################################################################################
#Lforbesi

P0GDlf=[0.005,0.025927046281147566,0.024436704492349456,368.48480088485326]
P0lf=[0.025927046281147566,0.024436704492349456,368.48480088485326]

datosGlf = np.loadtxt('GLforbesiForsythe1989_14°C.prn')
datosRlf = np.loadtxt('RLforbesiForsythe1989_14°C.prn')
datosERlf = np.loadtxt('ERLforbesiForsythe1989_14°C.prn')

xGlf = datosGlf[:, 0]
yGlf = datosGlf[:, 1]
xRlf = datosRlf[:, 0]
yRlf = datosRlf[:, 1]
xERlf = datosERlf[:, 0]
yERlf = datosERlf[:, 1]

xGlf_fit = np.linspace(xGlf[0], xGlf[-1], 1000, endpoint=True)
xRlf_fit = np.linspace(xRlf[0], xRlf[-1], 1000, endpoint=True)
xERlf_fit = np.linspace(xERlf[0], xERlf[-1], 1000, endpoint=True)
xDlf_fit = np.linspace(0,600, 1000, endpoint=True)

ax1.plot(xGlf_fit,Weight(xGlf_fit,*P0GDlf),'g',label='Model')
ax1.plot(xGlf,yGlf,'ro',label='Data')
ax1.legend(loc='best')
ax1.set_ylabel('Weight(g)')
ax1.set_title('1.A. L. forbesi 14°C')
ax1.annotate("$R^{2} = 0.992 $", (400, 20))
ax1.grid()

ax2.plot(xRlf_fit,Rate(xRlf_fit,*P0lf),'g',label='$\\alpha_{rel}$')
ax2.plot(xERlf,yERlf,'ro',label='$\\alpha_{emp}$')
ax2.legend(loc='best')
ax2.set_ylabel('Relative rate (1/day)')
ax2.set_title('1.B. L. forbesi 14°C')
ax2.grid()

ax3.plot(xDlf_fit,Derivative(xDlf_fit,*P0GDlf),'g',label='$dW/dt$')
ax3.legend(loc='best')
ax3.set_ylabel('Rate (g/day)')
ax3.set_title('1.C. L. forbesi 14°C')
ax3.axvline(x=379,color='red',linestyle='dashed')
ax3.axvline(x=592,color='red',linestyle='dashed')
ax3.annotate("$\Delta > 0 $", (450, 0.15))
ax3.grid()
#####################################################################################################3
#Lopalescens

P0GDlo=[0.002,0.065888887778094,0.049081458599352,124.04540885410361]
P0lo=[0.065888887778094,0.049081458599352,124.04540885410361]

datosGlo = np.loadtxt('GLopalescensYang1986_15°C.prn')
datosRlo = np.loadtxt('RLopalescensYang1986_15°C.prn')
datosERlo = np.loadtxt('ERLopalescensYang1986_15°C.prn')

xGlo = datosGlo[:, 0]
yGlo = datosGlo[:, 1]
xRlo = datosRlo[:, 0]
yRlo = datosRlo[:, 1]
xERlo = datosERlo[:, 0]
yERlo = datosERlo[:, 1]

xGlo_fit = np.linspace(xGlo[0], xGlo[-1], 1000, endpoint=True)
xRlo_fit = np.linspace(xRlo[0], xRlo[-1], 1000, endpoint=True)
xERlo_fit = np.linspace(xERlo[0], xERlo[-1], 1000, endpoint=True)
xDlo_fit = np.linspace(0,250, 1000, endpoint=True)

ax4.plot(xGlo_fit,Weight(xGlo_fit,*P0GDlo),'g',label='Model')
ax4.plot(xGlo,yGlo,'ro',label='Data')
ax4.legend(loc='best')
ax4.set_ylabel('Weight(g)')
ax4.set_title('2.A. L. opalescens 15°C')
ax4.annotate("$R^{2} = 0.999 $", (200, 10))
ax4.grid()

ax5.plot(xRlo_fit,Rate(xRlo_fit,*P0lo),'g',label='$\\alpha_{rel}$')
ax5.plot(xERlo,yERlo,'ro',label='$\\alpha_{emp}$')
ax5.legend(loc='best')
ax5.set_ylabel('Relative rate (1/day)')
ax5.set_title('2.B. L. opalescens 15°C ')
ax5.grid()

ax6.plot(xDlo_fit,Derivative(xDlo_fit,*P0GDlo),'g',label='$dW/dt$')
ax6.legend(loc='best')
ax6.set_ylabel('Rate (g/day)')
ax6.set_title('2.C. L. opalescens 15°C')
ax6.axvline(x=155,color='red',linestyle='dashed')
ax6.annotate("$\Delta < 0 $", (100, 0.5))
ax6.grid()

########################################################################################################
#Slessoniana 28°C

P0GDsl=[0.04,0.13861165134552583,0.098620449519759,42.77033723673206]
P0sl=[0.13861165134552583,0.098620449519759,42.77033723673206]

datosGsl = np.loadtxt('GSlessonianaNabhitabhata1996_28°C.prn')
datosRsl = np.loadtxt('RSlessonianaNabhitabhata1996_28°C.prn')
datosERsl = np.loadtxt('ERSlessonianaNabhitabhata1996_28°C.prn')

xGsl = datosGsl[:, 0]
yGsl = datosGsl[:, 1]
xRsl = datosRsl[:, 0]
yRsl = datosRsl[:, 1]
xERsl = datosERsl[:, 0]
yERsl = datosERsl[:, 1]

xGsl_fit = np.linspace(xGsl[0], xGsl[-1], 1000, endpoint=True)
xRsl_fit = np.linspace(xRsl[0], xRsl[-1], 1000, endpoint=True)
xERsl_fit = np.linspace(xERsl[0], xERsl[-1], 1000, endpoint=True)
xDsl_fit = np.linspace(0,140, 1000, endpoint=True)

ax7.plot(xGsl_fit,Weight(xGsl_fit,*P0GDsl),'g',label='Model')
ax7.plot(xGsl,yGsl,'ro',label='Data')
ax7.legend(loc='best')
ax7.set_ylabel('Weight(g)')
ax7.set_title('3.A. S. lessoniana 28°C')
ax7.annotate("$R^{2} = 0.995 $", (110, 100))
ax7.grid()

ax8.plot(xRsl_fit,Rate(xRsl_fit,*P0sl),'g',label='$\\alpha_{rel}$')
ax8.plot(xERsl,yERsl,'ro',label='$\\alpha_{emp}$')
ax8.legend(loc='best')
ax8.set_ylabel('Relative rate(1/day)')
ax8.set_title('3.B. S. lessoniana 28°C ')
ax8.grid()

ax9.plot(xDsl_fit,Derivative(xDsl_fit,*P0GDsl),'g',label='$dW/dt$')
ax9.legend(loc='best')
ax9.set_ylabel('Rate (g/day)')
ax9.set_title('3.C. S. lessoniana 28°C')
ax9.axvline(x=58,color='red',linestyle='dashed')
ax9.annotate("$\Delta < 0 $", (30, 25))
ax9.grid()

########################################################################################################
#Ehyllebergy 28°C

P0GDeh=[0.004,0.11811089059518458,0.11175516140796583,58.85460368807109]
P0eh=[0.11811089059518458,0.11175516140796583,58.85460368807109]

datosGeh = np.loadtxt('GEhyllebergyNabhitabhata2005_28°C.prn')
datosReh = np.loadtxt('REhyllebergyNabhitabhata2005_28°C.prn')
datosEReh = np.loadtxt('EREhyllebergyNabhitabhata2005_28°C.prn')

xGeh = datosGeh[:, 0]
yGeh = datosGeh[:, 1]
xReh = datosReh[:, 0]
yReh = datosReh[:, 1]
xEReh = datosEReh[:, 0]
yEReh = datosEReh[:, 1]

xGeh_fit = np.linspace(xGeh[0], xGeh[-1], 1000, endpoint=True)
xReh_fit = np.linspace(xReh[0], xReh[-1], 1000, endpoint=True)
xEReh_fit = np.linspace(xEReh[0], xEReh[-1], 1000, endpoint=True)
xDeh_fit = np.linspace(0,120, 1000, endpoint=True)

ax10.plot(xGeh_fit,Weight(xGeh_fit,*P0GDeh),'g',label='Model')
ax10.plot(xGeh,yGeh,'ro',label='Data')
ax10.legend(loc='best')
ax10.set_xlabel('Time(days)')
ax10.set_ylabel('Weight(g)')
ax10.set_title('4.A. E. hyllebergy 28°C')
ax10.annotate("$R^{2} = 0.993 $", (100, 1))
ax10.grid()

ax11.plot(xReh_fit,Rate(xReh_fit,*P0eh),'g',label='$\\alpha_{rel}$')
ax11.plot(xEReh,yEReh,'ro',label='$\\alpha_{emp}$')
ax11.legend(loc='best')
ax11.set_xlabel('Time(days)')
ax11.set_ylabel('Relative rate(1/day)')
ax11.set_title('4.B. E. hyllebergy 28°C ')
ax11.grid()

ax12.plot(xDeh_fit,Derivative(xDeh_fit,*P0GDeh),'g',label='$dW/dt$')
ax12.legend(loc='best')
ax12.set_xlabel('Time(days)')
ax12.set_ylabel('Rate(g/day)')
ax12.set_title('4.C. E. hyllebergy 28°C')
ax12.axvline(x=61,color='red',linestyle='dashed')
ax12.axvline(x=109,color='red',linestyle='dashed')
ax12.annotate("$\Delta > 0 $", (80, 0.02))
ax12.grid()


########################################################################################################

plt.savefig('Figure 2. Squids.png', dpi=1000.0, bbox_inches='tight', pad_inches=0.5)

#END OF CODE