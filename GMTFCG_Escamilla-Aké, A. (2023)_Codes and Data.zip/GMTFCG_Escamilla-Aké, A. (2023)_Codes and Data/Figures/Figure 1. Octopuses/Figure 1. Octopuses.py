# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 08:41:41 2023

@author: Ángel Escamilla
"""
#BEGIN OF CODE

#**LIBRARY AND ROUTINE
import numpy as np
import matplotlib.pyplot as plt  

#**CONFIGURATION
fig=plt.figure(figsize=(20,15))
fig.tight_layout()

ax1=fig.add_subplot(4,3,1)
ax2=fig.add_subplot(4,3,2)
ax3=fig.add_subplot(4,3,3)
ax4=fig.add_subplot(4,3,4)
ax5=fig.add_subplot(4,3,5)
ax6=fig.add_subplot(4,3,6)
ax7=fig.add_subplot(4,3,7)
ax8=fig.add_subplot(4,3,8)
ax9=fig.add_subplot(4,3,9)
ax10=fig.add_subplot(4,3,10)
ax11=fig.add_subplot(4,3,11)
ax12=fig.add_subplot(4,3,12)


#**BIOMASS GROWTH FUNCTION. We define the biomass growth function, Eq. (7) in our paper
def Weight(t,W0,a,b,mu):
    return W0*(np.exp((a-b)*t))*((1+np.exp(b*mu))/((1+np.exp(b*(mu-t)))))

#**RELATIVE GROWTH RATE. We define the biomass growth function, Eq. (4) in our paper
def Rate(t,a,b,mu):
    return a-(b/(1+np.exp(b*((mu)-t))))

#**TIME DERIVATIVE OF BIOMASS GROWTH FUNCTION. We calculate the time derivative biomass growth function
def Derivative(t,W0,a,b,mu):
   return W0*(1+np.exp(b*mu))*(((b*np.exp((a-b)*t+b*(mu-t)))/(1+np.exp(b*(mu-t)))**2)+(((a-b)*np.exp((a-b)*t))/(1+np.exp(b*(mu-t)))))

########################################################################################
#Ojoubini

P0GDoj=[0.035,0.04529569360280526,0.043167416904743204,136.17183060466422]
P0oj=[0.04529569360280526,0.043167416904743204,136.17183060466422]

datosGoj = np.loadtxt('GOjoubiniForsythe1984_25°C.prn')
datosRoj = np.loadtxt('ROjoubiniForsythe1984_25°C.prn')
datosERoj = np.loadtxt('EROjoubiniForsythe1984_25°C.prn')

xGoj = datosGoj[:, 0]
yGoj = datosGoj[:, 1]
xRoj = datosRoj[:, 0]
yRoj = datosRoj[:, 1]
xERoj = datosERoj[:, 0]
yERoj = datosERoj[:, 1]

xGoj_fit = np.linspace(xGoj[0], xGoj[-1], 1000, endpoint=True)
xRoj_fit = np.linspace(xRoj[0], xRoj[-1], 1000, endpoint=True)
xERoj_fit = np.linspace(xERoj[0], xERoj[-1], 1000, endpoint=True)
xDoj_fit = np.linspace(0,300, 1000, endpoint=True)

ax1.plot(xGoj_fit,Weight(xGoj_fit,*P0GDoj),'g',label='Model')
ax1.plot(xGoj,yGoj,'ro',label='Data')
ax1.legend(loc='best')
ax1.set_ylabel('Weight(g)')
ax1.set_title('1.A. O. joubini 25°C')
ax1.annotate("$R^{2} = 0.996 $", (200, 3))
ax1.grid()

ax2.plot(xRoj_fit,Rate(xRoj_fit,*P0oj),'g',label='$\\alpha_{rel}$')
ax2.plot(xERoj,yERoj,'ro',label='$\\alpha_{emp}$')
ax2.legend(loc='best')
ax2.set_ylabel('Relative rate (1/day)')
ax2.set_title('1.B. O. joubini 25°C')
ax2.grid()

ax3.plot(xDoj_fit,Derivative(xDoj_fit,*P0GDoj),'g',label='$dW/dt$')
ax3.legend(loc='best')
ax3.set_ylabel('Rate (g/day)')
ax3.set_title('1.C. O. joubini 25°C')
ax3.axvline(x=141,color='red',linestyle='dashed')
ax3.axvline(x=273,color='red',linestyle='dashed')
ax3.annotate("$\Delta > 0 $", (230, 0.15))
ax3.grid()

#####################################################################################################3
#Omaya

P0GDom=[0.1,0.05696299810991783,0.050615692033742055,173.93946465632968]
P0om=[0.05696299810991783,0.050615692033742055,173.93946465632968]

datosGom = np.loadtxt('GOmayaVanHeukelem1976_25°C.prn')
datosRom = np.loadtxt('ROmayaVanHeukelem1976_25°C.prn')
datosERom = np.loadtxt('EROmayaVanHeukelem1976_25°C.prn')

xGom = datosGom[:, 0]
yGom = datosGom[:, 1]
xRom = datosRom[:, 0]
yRom = datosRom[:, 1]
xERom = datosERom[:, 0]
yERom = datosERom[:, 1]

xGom_fit = np.linspace(xGom[0], xGom[-1], 1000, endpoint=True)
xRom_fit = np.linspace(xRom[0], xRom[-1], 1000, endpoint=True)
xERom_fit = np.linspace(xERom[0], xERom[-1], 1000, endpoint=True)
xDom_fit = np.linspace(0,300, 1000, endpoint=True)

ax4.plot(xGom_fit,Weight(xGom_fit,*P0GDom),'g',label='Model')
ax4.plot(xGom,yGom,'ro',label='Data')
ax4.legend(loc='best')
ax4.set_ylabel('Weight(g)')
ax4.set_title('2.A. O. maya 25°C')
ax4.annotate("$R^{2} = 0.999 $", (200, 500))
ax4.grid()

ax5.plot(xRom_fit,Rate(xRom_fit,*P0om),'g',label='$\\alpha_{rel}$')
ax5.plot(xERom,yERom,'ro',label='$\\alpha_{emp}$')
ax5.legend(loc='best')
ax5.set_ylabel('Relative rate (1/day)')
ax5.set_title('2.B. O. maya 25°C ')
ax5.grid()

ax6.plot(xDom_fit,Derivative(xDom_fit,*P0GDom),'g',label='$dW/dt$')
ax6.legend(loc='best')
ax6.set_ylabel('Rate (g/day)')
ax6.set_title('2.C. O. maya 25°C')
ax6.axvline(x=186,color='red',linestyle='dashed')
ax6.axvline(x=249,color='red',linestyle='dashed')
ax6.annotate("$\Delta > 0 $", (210, 15))
ax6.grid()

########################################################################################################
#Obimaculoides 18°C

P0GDob18=[0.07,0.03350041159410082,0.026871872438137615,239.40702058235888]
P0ob18=[0.03350041159410082,0.026871872438137615,239.40702058235888]

datosGob18 = np.loadtxt('GObimaculoidesForsythe1988_18°C.prn')
datosRob18 = np.loadtxt('RObimaculoidesForsythe1988_18°C.prn')
datosERob18 = np.loadtxt('ERObimaculoidesForsythe1988_18°C.prn')

xGob18 = datosGob18[:, 0]
yGob18 = datosGob18[:, 1]
xRob18 = datosRob18[:, 0]
yRob18 = datosRob18[:, 1]
xERob18 = datosERob18[:, 0]
yERob18 = datosERob18[:, 1]

xGob18_fit = np.linspace(xGob18[0], xGob18[-1], 1000, endpoint=True)
xRob18_fit = np.linspace(xRob18[0], xRob18[-1], 1000, endpoint=True)
xERob18_fit = np.linspace(xERob18[0], xERob18[-1], 1000, endpoint=True)
xDob18_fit = np.linspace(0,400, 1000, endpoint=True)

ax7.plot(xGob18_fit,Weight(xGob18_fit,*P0GDob18),'g',label='Model')
ax7.plot(xGob18,yGob18,'ro',label='Data')
ax7.legend(loc='best')
ax7.set_ylabel('Weight(g)')
ax7.set_title('3.A. O. bimaculoides 18°C')
ax7.annotate("$R^{2} = 0.997 $", (320, 150))
ax7.grid()

ax8.plot(xRob18_fit,Rate(xRob18_fit,*P0ob18),'g',label='$\\alpha_{rel}$')
ax8.plot(xERob18,yERob18,'ro',label='$\\alpha_{emp}$')
ax8.legend(loc='best')
ax8.set_ylabel('Relative rate (1/day)')
ax8.set_title('3.B. O. bimaculoides 18°C ')
ax8.grid()

ax9.plot(xDob18_fit,Derivative(xDob18_fit,*P0GDob18),'g',label='$dW/dt$')
ax9.legend(loc='best')
ax9.set_ylabel('Rate (g/day)')
ax9.set_title('3.C. O. bimaculoides 18°C')
ax9.axvline(x=302,color='red',linestyle='dashed')
ax9.annotate("$\Delta < 0 $", (245, 1.5))
ax9.grid()

########################################################################################################
#Obimaculoides 23°C

P0GDob23=[0.07,0.04255868431959052,0.03896228556551779,196.34777146168005]
P0ob23=[0.04255868431959052,0.03896228556551779,196.34777146168005]

datosGob23 = np.loadtxt('GObimaculoidesForsythe1988_23°C.prn')
datosRob23 = np.loadtxt('RObimaculoidesForsythe1988_23°C.prn')
datosERob23 = np.loadtxt('ERObimaculoidesForsythe1988_23°C.prn')

xGob23 = datosGob23[:, 0]
yGob23 = datosGob23[:, 1]
xRob23 = datosRob23[:, 0]
yRob23 = datosRob23[:, 1]
xERob23 = datosERob23[:, 0]
yERob23 = datosERob23[:, 1]

xGob23_fit = np.linspace(xGob23[0], xGob23[-1], 1000, endpoint=True)
xRob23_fit = np.linspace(xRob23[0], xRob23[-1], 1000, endpoint=True)
xERob23_fit = np.linspace(xERob23[0], xERob23[-1], 1000, endpoint=True)
xDob23_fit = np.linspace(0,400, 1000, endpoint=True)

ax10.plot(xGob23_fit,Weight(xGob23_fit,*P0GDob23),'g',label='Model')
ax10.plot(xGob23,yGob23,'ro',label='Data')
ax10.legend(loc='best')
ax10.set_xlabel('Time(days)')
ax10.set_ylabel('Weight(g)')
ax10.set_title('4.A. O. bimaculoides 23°C')
ax10.annotate("$R^{2} = 0.984 $", (300, 150))
ax10.grid()

ax11.plot(xRob23_fit,Rate(xRob23_fit,*P0ob23),'g',label='$\\alpha_{rel}$')
ax11.plot(xERob23,yERob23,'ro',label='$\\alpha_{emp}$')
ax11.legend(loc='best')
ax11.set_xlabel('Time(days)')
ax11.set_ylabel('Relative rate (1/day)')
ax11.set_title('4.B. O. bimaculoides 23°C ')
ax11.grid()

ax12.plot(xDob23_fit,Derivative(xDob23_fit,*P0GDob23),'g',label='$dW/dt$')
ax12.legend(loc='best')
ax12.set_xlabel('Time(days)')
ax12.set_ylabel('Rate (g/day)')
ax12.set_title('4.C. O. bimaculoides 23°C')
ax12.axvline(x=207,color='red',linestyle='dashed',label='$\\mu_{1}$')
ax12.axvline(x=312,color='red',linestyle='dashed')
ax12.annotate("$\Delta >0 $", (250, 1))
ax12.grid()

########################################################################################################

plt.savefig('Figure 1. Octopuses.png', dpi=1000.0, bbox_inches='tight', pad_inches=0.5)

#END OF CODE