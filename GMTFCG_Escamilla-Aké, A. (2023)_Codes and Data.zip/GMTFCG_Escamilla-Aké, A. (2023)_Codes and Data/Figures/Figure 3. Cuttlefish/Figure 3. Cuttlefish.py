# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 08:41:41 2023

@author: Ángel Escamilla
"""
#BEGIN OF CODE

#**LIBRARY AND ROUTINE
import numpy as np  
import matplotlib.pyplot as plt  

#**CONFIGURATION

fig=plt.figure(figsize=(20,15))
fig.tight_layout()

ax1=fig.add_subplot(4,3,1)
ax2=fig.add_subplot(4,3,2)
ax3=fig.add_subplot(4,3,3)
ax4=fig.add_subplot(4,3,4)
ax5=fig.add_subplot(4,3,5)
ax6=fig.add_subplot(4,3,6)

ax7=fig.add_subplot(4,3,7)
ax8=fig.add_subplot(4,3,8)
ax9=fig.add_subplot(4,3,9)
ax10=fig.add_subplot(4,3,10)
ax11=fig.add_subplot(4,3,11)
ax12=fig.add_subplot(4,3,12)

#**BIOMASS GROWTH FUNCTION. We define the biomass growth function, Eq. (7) in our paper
def Weight(t,W0,a,b,mu):
    return W0*(np.exp((a-b)*t))*((1+np.exp(b*mu))/((1+np.exp(b*(mu-t)))))

#**RELATIVE GROWTH RATE. We define the biomass growth function, Eq. (4) in our paper
def Rate(t,a,b,mu):
    return a-(b/(1+np.exp(b*((mu)-t))))

#**TIME DERIVATIVE OF BIOMASS GROWTH FUNCTION. We calculate the time derivative biomass growth function
def Derivative(t,W0,a,b,mu):
   return W0*(1+np.exp(b*mu))*(((b*np.exp((a-b)*t+b*(mu-t)))/(1+np.exp(b*(mu-t)))**2)+(((a-b)*np.exp((a-b)*t))/(1+np.exp(b*(mu-t)))))


########################################################################################
#Spharaonis 28°C

P0GDsp=[0.18,0.05485466820073328,0.044972492378843404,118.18348918976501]
P0sp=[0.05485466820073328,0.044972492378843404,118.18348918976501]

datosGsp = np.loadtxt('GSpharaonisNabhitabhata1999_28°C.prn')
datosRsp = np.loadtxt('RSpharaonisNabhitabhata1999_28°C.prn')
datosERsp = np.loadtxt('ERSpharaonisNabhitabhata1999_28°C.prn')

xGsp = datosGsp[:, 0]
yGsp = datosGsp[:, 1]
xRsp = datosRsp[:, 0]
yRsp = datosRsp[:, 1]
xERsp = datosERsp[:, 0]
yERsp = datosERsp[:, 1]

xGsp_fit = np.linspace(xGsp[0], xGsp[-1], 1000, endpoint=True)
xRsp_fit = np.linspace(xRsp[0], xRsp[-1], 1000, endpoint=True)
xERsp_fit = np.linspace(xERsp[0], xERsp[-1], 1000, endpoint=True)
xDsp_fit = np.linspace(0,220, 1000, endpoint=True)

ax1.plot(xGsp_fit,Weight(xGsp_fit,*P0GDsp),'g',label='Model')
ax1.plot(xGsp,yGsp,'ro',label='Data')
ax1.legend(loc='best')
ax1.set_ylabel('Weight(g)')
ax1.set_title('1.A. S. pharaonis 28°C')
ax1.annotate("$R^{2} = 0.991 $", (170, 50))
ax1.grid()

ax2.plot(xRsp_fit,Rate(xRsp_fit,*P0sp),'g',label='$\\alpha_{rel}$')
ax2.plot(xERsp,yERsp,'ro',label='$\\alpha_{emp}$')
ax2.legend(loc='best')
ax2.set_ylabel('Relative rate(1/day)')
ax2.set_title('1.B. S. pharaonis 28°C')
ax2.grid()

ax3.plot(xDsp_fit,Derivative(xDsp_fit,*P0GDsp),'g',label='$dW/dt$')
ax3.legend(loc='best')
ax3.set_ylabel('Rate (g/day)')
ax3.set_title('1.C. S. pharaonis 28°C')
ax3.axvline(x=157,color='red',linestyle='dashed')
ax3.annotate("$\Delta < 0 $", (120, 1.3))
ax3.grid()
#####################################################################################################3
#Sinermis

P0GDsi=[0.04,0.09739100337409665,0.09387717368791136,70.71191988241372]
P0si=[0.09739100337409665,0.09387717368791136,70.71191988241372]

datosGsi = np.loadtxt('GSinermisNabhitabhata1997_28°C.prn')
datosRsi = np.loadtxt('RSinermisNabhitabhata1997_28°C.prn')
datosERsi = np.loadtxt('ERSinermisNabhitabhata1997_28°C.prn')

xGsi = datosGsi[:, 0]
yGsi = datosGsi[:, 1]
xRsi = datosRsi[:, 0]
yRsi = datosRsi[:, 1]
xERsi = datosERsi[:, 0]
yERsi = datosERsi[:, 1]

xGsi_fit = np.linspace(xGsi[0], xGsi[-1], 1000, endpoint=True)
xRsi_fit = np.linspace(xRsi[0], xRsi[-1], 1000, endpoint=True)
xERsi_fit = np.linspace(xERsi[0], xERsi[-1], 1000, endpoint=True)
xDsi_fit = np.linspace(0,160, 1000, endpoint=True)

ax4.plot(xGsi_fit,Weight(xGsi_fit,*P0GDsi),'g',label='Model')
ax4.plot(xGsi,yGsi,'ro',label='Data')
ax4.legend(loc='best')
ax4.set_ylabel('Weight(g)')
ax4.set_title('2. A. S. inermis 28°C')
ax4.annotate("$R^{2} = 0.998 $", (100, 10))
ax4.grid()

ax5.plot(xRsi_fit,Rate(xRsi_fit,*P0si),'g',label='$\\alpha_{rel}$')
ax5.plot(xERsi,yERsi,'ro',label='$\\alpha_{emp}$')
ax5.legend(loc='best')
ax5.set_ylabel('Relative rate (1/day)')
ax5.set_title('2. B. S. inermis 28°C ')
ax5.grid()

ax6.plot(xDsi_fit,Derivative(xDsi_fit,*P0GDsi),'g',label='$dW/dt$')
ax6.legend(loc='best')
ax6.set_ylabel('Rate (g/day)')
ax6.set_title('2. C. S. inermis 28°C')
ax6.axvline(x=72,color='red',linestyle='dashed')
ax6.axvline(x=140,color='red',linestyle='dashed')
ax6.annotate("$\Delta > 0 $", (100, 0.1))
ax6.grid()

########################################################################################################
#Sofficinalis 15°C

P0GDso15=[0.178,0.04000453024781951,0.02871869033215451,163.11657932761224]

datosGso15 = np.loadtxt('GSofficinalisDomingues2002_15°C.prn')
datosRso15 = np.loadtxt('RSofficinalisDomingues2002_15°C.prn')
datosERso15 = np.loadtxt('ERSofficinalisDomingues2002_15°C.prn')

xGso15 = datosGso15[:, 0]
yGso15 = datosGso15[:, 1]
xRso15 = datosRso15[:, 0]
yRso15 = datosRso15[:, 1]
xERso15 = datosERso15[:, 0]
yERso15 = datosERso15[:, 1]

xGso15_fit = np.linspace(xGso15[0], xGso15[-1], 1000, endpoint=True)
xRso15_fit = np.linspace(xRso15[0], xRso15[-1], 1000, endpoint=True)
xERso15_fit = np.linspace(xERso15[0], xERso15[-1], 1000, endpoint=True)
xDso15_fit = np.linspace(0,250, 1000, endpoint=True)

ax7.plot(xGso15_fit,Weight(xGso15_fit,*P0GDso15),'g',label='Model')
ax7.plot(xGso15,yGso15,'ro',label='Data')
ax7.legend(loc='best')
ax7.set_ylabel('Weight(g)')
ax7.set_title('3.A. S. officinalis 15°C')
ax7.annotate("$R^{2} = 0.997 $", (200, 50))
ax7.grid()

ax8.plot(xRso15_fit,Rate(xRso15_fit,*P0so15),'g',label='$\\alpha_{rel}$')
ax8.plot(xERso15,yERso15,'ro',label='$\\alpha_{emp}$')
ax8.legend(loc='best')
ax8.set_ylabel('Relative rate(1/day)')
ax8.set_title('3.B. S. officinalis 15°C ')
ax8.grid()

ax9.plot(xDso15_fit,Derivative(xDso15_fit,*P0GDso15),'g',label='$dW/dt$')
ax9.legend(loc='best')
ax9.set_ylabel('Rate (g/day)')
ax9.set_title('3.C. S. officinalis 15°C')
ax9.axvline(x=215,color='red',linestyle='dashed')
ax9.annotate("$\Delta < 0 $", (170, 0.5))
ax9.grid()

########################################################################################################
#Sofficinalis 27°C

P0GDso27=[0.223,0.1015995856809687,0.09048539092015806,54.90753752528491]
P0so27=[0.1015995856809687,0.09048539092015806,54.90753752528491]

datosGso27 = np.loadtxt('GSofficinalisDomingues2002_27°C.prn')
datosRso27 = np.loadtxt('RSofficinalisDomingues2002_27°C.prn')
datosERso27 = np.loadtxt('ERSofficinalisDomingues2002_27°C.prn')

xGso27 = datosGso27[:, 0]
yGso27 = datosGso27[:, 1]
xRso27 = datosRso27[:, 0]
yRso27 = datosRso27[:, 1]
xERso27 = datosERso27[:, 0]
yERso27 = datosERso27[:, 1]

xGso27_fit = np.linspace(xGso27[0], xGso27[-1], 1000, endpoint=True)
xRso27_fit = np.linspace(xRso27[0], xRso27[-1], 1000, endpoint=True)
xERso27_fit = np.linspace(xERso27[0], xERso27[-1], 1000, endpoint=True)
xDso27_fit = np.linspace(0,160, 1000, endpoint=True)

ax10.plot(xGso27_fit,Weight(xGso27_fit,*P0GDso27),'g',label='Model')
ax10.plot(xGso27,yGso27,'ro',label='Data')
ax10.legend(loc='best')
ax10.set_xlabel('Time(days)')
ax10.set_ylabel('Weight(g)')
ax10.set_title('4.A. S. officinalis 27°C')
ax10.annotate("$R^{2} = 0.994 $", (125, 50))
ax10.grid()

ax11.plot(xRso27_fit,Rate(xRso27_fit,*P0so27),'g',label='$\\alpha_{rel}$')
ax11.plot(xERso27,yERso27,'ro',label='$\\alpha_{emp}$')
ax11.legend(loc='best')
ax11.set_xlabel('Time(days)')
ax11.set_ylabel('Relative rate(1/day)')
ax11.set_title('4.B. S. officinalis 27°C ')
ax11.grid()

ax12.plot(xDso27_fit,Derivative(xDso27_fit,*P0GDso27),'g',label='$dW/dt$')
ax12.legend(loc='best')
ax12.set_xlabel('Time(days)')
ax12.set_ylabel('Rate (g/day)')
ax12.set_title('4.C. S. officinalis 27°C')
ax12.axvline(x=61,color='red',linestyle='dashed')
ax12.axvline(x=97,color='red',linestyle='dashed')
ax12.annotate("$\Delta > 0 $", (70, 0.5))
ax12.grid()

########################################################################################################

plt.savefig('Figure 3. Cuttlefish.png', dpi=1000.0, bbox_inches='tight', pad_inches=0.5)

#END OF CODE