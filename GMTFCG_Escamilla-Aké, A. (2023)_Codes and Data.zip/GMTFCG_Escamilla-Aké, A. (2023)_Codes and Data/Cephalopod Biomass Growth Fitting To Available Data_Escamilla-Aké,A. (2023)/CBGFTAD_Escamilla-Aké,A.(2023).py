# -*- coding: utf-8 -*-
"""
Created on Mon Feb 20 08:41:41 2023

@author: Ángel Escamilla-Aké
"""
#BEGIN OF CODE

#**LIBRARY AND ROUTINE
from scipy.optimize import curve_fit
import numpy as np  
import matplotlib.pyplot as plt  
import cmath 

#**PARAMETERS. We define the parameters of model.
#W0:= initial weight
#a:= parameter alpha
#b:= parameter beta
#k:= parameter kappa

#**INITIAL WEIGHT. We fix the value of initial weight
#W0=0.035#Octopus joubini, 25°C
W0=0.1#Octopus maya, 25°C
#W0=0.07#Octopus bimaculoides, 18°C
#W0=0.07#Octopus bimaculoides, 23°C
#W0=0.005#Loligo forbesi, 14°C
#W0=0.002#Loligo opalescens, 15°C
#W0=0.04#Sepioteuthis Lessoniana, 28°C
#W0=0.004#Euprymna hyllebergi, 28°C
#W0=0.18#Sepia pharaonis, 28°C
#W0=0.04#Sepiella inermis, 28°C
#W0=0.178#Sepia officinalis, 15°C
#W0=0.223#Sepia officinalis, 27°C

#**BIOMASS GROWTH FUNCTION. We define the biomass growth function, Eq. (7) in our paper
def Weight(t,a,b,k):
    return W0*(np.exp((a-b)*t))*((1+np.exp(b*k))/((1+np.exp(b*(k-t))))) 

#**RELATIVE GROWTH RATE. We define the relative growth rate, Eq. (4) in our paper
def Rate(t,a,b,k):
    return a-(b/(1+np.exp(b*(k-t))))

#**PARAMETER VECTOR. Give a starting value: P0=[a,b,k]
#P0=[0.04529569360280526,0.043167416904743204,136.17183060466422]#O.joubini, 25°C
P0=[0.05696299810991783,0.050615692033742055,173.93946465632968]#O.maya, 25°C
#P0=[0.03350041159410082,0.026871872438137615,239.40702058235888]#O.bimaculoides, 18°C
#P0=[0.04255868431959052,0.03896228556551779,196.34777146168005]#O.bimaculoides, 23°C 
#P0=[0.025927046281147566,0.024436704492349456,368.48480088485326]#L.forbesi, 14°C 
#P0=[0.065888887778094,0.049081458599352,124.04540885410361]#L.opalescens, 15°C 
#P0=[0.13861165134552583,0.098620449519759,42.77033723673206]#S.lessoniana, 28°C  
#P0=[0.11811089059518458,0.11175516140796583,58.85460368807109]#E.hyllebergy, 28°C 
#P0=[0.05485466820073328,0.044972492378843404,118.18348918976501]#S.pharaonis, 28°C 
#P0=[0.09739100337409665,0.09387717368791136,70.71191988241372]#S inermis, 28°C 
#P0=[0.04000453024781951,0.02871869033215451,163.11657932761224]#S officinalis, 15°C  
#P0=[0.1015995856809687,0.09048539092015806,54.90753752528491]#S officinalis, 27°C  

#**DATA. We load the data
#OCTOPUSES
#datos = np.loadtxt('GOjoubiniForsythe1984_25°C.prn')
datos = np.loadtxt('GOmayaVanHeukelem1976_25°C.prn')
#datos = np.loadtxt('GObimaculoidesForsythe1988_18°C.prn')
#datos = np.loadtxt('GObimaculoidesForsythe1988_23°C.prn')
#SQUIDS
#datos = np.loadtxt('GLforbesiForsythe1989_14°C.prn')
#datos = np.loadtxt('GLopalescensYang1986_15°C.prn')
#datos = np.loadtxt('GSlessonianaNabhitabhata1996_28°C.prn')
#datos = np.loadtxt('GEhyllebergyNabhitabhata2005_28°C.prn')
#CUTTLEFISH
#datos = np.loadtxt('GSpharaonisNabhitabhata1999_28°C.prn')
#datos = np.loadtxt('GSinermisNabhitabhata1997_28°C.prn')
#datos = np.loadtxt('GSofficinalisDomingues2002_15°C.prn')
#datos = np.loadtxt('GSofficinalisDomingues2002_27°C.prn')

#**FITTING. We make the fitting to obtain the parameters alpha, beta and kappa of our model
x = datos[:, 0]
y = datos[:, 1]
popt, pcov= curve_fit(Weight,x,y,p0=P0)
P0=popt
#**CALCULATION AND DISPLAY OF VALUES
print('Determination coefficient')
ss_res = np.sum( (y - Weight(x, *popt))**2  )
ss_tot = np.sum( (y- np.mean(y) )**2  )
R2     = 1 - (ss_res / ss_tot)
print('R2 = {:10.8f}'.format(R2) )
P=np.vectorize(P0)
P=P0
print('alpha')
alpha=P[0]
print(alpha)
print('beta')
beta=P[1]
print(beta)
print('kappa')
kappa=P[2]
print(kappa)
print('Delta')
Delta=beta**2-4*alpha*(alpha-beta)
print(Delta)
print('mu1')
mu1=kappa+(1/beta)*cmath.log(((2*alpha**2)/((alpha+beta)**2-3*alpha**2+beta*cmath.sqrt(Delta))))
print(mu1)
print('|mu1|')
print(abs(mu1))
print('mu2')
mu2=kappa+(1/beta)*cmath.log(((2*alpha**2)/((alpha+beta)**2-3*alpha**2-beta*cmath.sqrt(Delta))))
print(mu2)
print('|mu2|')
print(abs(mu2))
print('alpha relative average')
Aave=alpha-(1/mu2)*cmath.log((cmath.exp(beta*mu2)+cmath.exp(beta*kappa))/(1+cmath.exp(beta*kappa)))
print(Aave)
print('|A_rel_ave|')
print(abs(Aave))
print('Aeff0')
Aeff0=Rate(0,*P0)
print(Aeff0)
x_fit = np.linspace(x[0], x[-1], 1000, endpoint=True)
plt.plot(x,y,'o',label = 'Data')
plt.plot(x_fit,Weight(x_fit,*popt),'g--',label='Model fit')
plt.legend(loc='best')
plt.xlabel('Time (days)')
plt.ylabel('Weight (grams)')
plt.tight_layout()
plt.grid()
plt.show()

#END OF CODE
